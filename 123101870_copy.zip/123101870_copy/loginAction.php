<?php
header("Content-Type: text/html;charset=utf-8");

session_start();

	require("dbconfig.php");
	require("functions.php");



	
	switch($_GET["act"]){
		case "login": 
			
			$username 		= trim($_POST["username"]);
			$password 		= trim($_POST["password"]);
			$md5Pwd 		= md5($password);// encryption for password
			//2. verification
			if(empty($username)){
				alertMes('Must Input user name', 'login.php');
			}
			if(empty($password)){
				alertMes('Must input password', 'login.php');
			}
			
			
			// Determine if a user exists
			$sql_count = "select * from user where username = '{$username}' and password='{$md5Pwd}'";
			$result = mysql_query($sql_count);
			
			
			if($result && mysql_num_rows($result)>0){
				$item = mysql_fetch_assoc($result);
				if($username == 'admin'){
					$_SESSION['adminName'] = $item['username'];
					$_SESSION['adminId'] = $item['id'];
					$_SESSION['userName'] = $item['username'];
					$_SESSION['userId'] = $item['id'];
					alertMes('Log In Successfully', 'index.php');
				}else{
					$_SESSION['userName'] = $item['username'];
					$_SESSION['userId'] = $item['id'];
					alertMes('Log In Successfully', 'index.php');
				}
			}else{
				alertMes('Fail to log in', 'login.php');
			}

			
			break;
		
		case "logout": 
	
			$_SESSION['adminName'] = '';
			$_SESSION['adminId'] = '';
			$_SESSION['userName'] = '';
			$_SESSION['userId'] = '';
			
		
			header("Location:index.php");
			break;

	}


mysql_close();


