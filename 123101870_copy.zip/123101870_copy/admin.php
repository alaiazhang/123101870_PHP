<?php 
session_start();
require("functions.php");
checkLogined();
?>
<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Back-end Management</title>
		<link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
	</head>
	<body>
		<div class="admin_head">
			<h3>Back-end Management</h3>
		</div>
		<div class="admin_content">
		
        	<div class="menu">
        		<div class="cont">
        			<div class="title"> </div>
        			<ul class="mList">
        				<li>
	                        <h3>User Management</h3>
	                        <dl>
	                        	<dd><a href="admin_user/addUser.php" target="mainFrame">Add User</a></dd>
	                            <dd><a href="admin_user/userList.php" target="mainFrame">User List</a></dd>
	                        </dl>
                    	</li>
        				<li>
	                        <h3>Product Management</h3>
	                        <dl>
	                        	<dd><a href="admin_goods/addGoods.php" target="mainFrame">Add Product</a></dd>
	                            <dd><a href="admin_goods/goodsList.php" target="mainFrame">Product List</a></dd>
	                        </dl>
                    	</li>
                    	<li>
	                        <h3>Order Management</h3>
	                        <dl>
	                            <dd><a href="admin_order/orderList.php" target="mainFrame">Order List</a></dd>
	                        </dl>
                    	</li>
                    	<li>
	                        <h3>System Setting</h3>
	                        <dl>
	                            <dd><a href="index.php">Back Homepage</a></dd>
	                        </dl>
	                        <dl>
	                            <dd><a href="loginAction.php?act=logout">Exit</a></dd>
	                        </dl>
                    	</li>
        			</ul>
        		</div>
        	</div>
		
			<div class="main">
	            <div class="cont">     
	                <iframe src="adminMain.php"  frameborder="0" name="mainFrame" width="100%" height="800"></iframe>
	            </div>
        	</div>
        	
		</div>
			
		
	</body>
</html>