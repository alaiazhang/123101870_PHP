<?php 
error_reporting(0);


 
date_default_timezone_set("Asia/Shanghai");
  
 

 
/**
 * 
 * @param unknown 
 * @param unknown 
 * @return string
 */
function errorTip($msg, $backUrl){
	return "<div style='text-align:center;margin-top:100px;font-size:18px;'>【{$msg}】"."<a href='{$backUrl}'>Click Back</a></div>";
}

function  alertMes($mes, $url) {
	echo "<script>alert('{$mes}');</script>";
	echo "<script>window.location='{$url}';</script>";
}

/**
 *
 */
function checkLogined() {
	if((!isset($_SESSION['adminId']) || $_SESSION['adminId'] == "")) {
		alertMes("Please log in first", "login.php");
	}
}
/**
 *
 */
function checkUserLogined() {
	if((!isset($_SESSION['userId']) || $_SESSION['userId'] == "")) {
		alertMes("Please log in first", "login.php");
	}
}