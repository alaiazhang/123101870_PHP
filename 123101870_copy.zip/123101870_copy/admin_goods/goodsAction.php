<?php
error_reporting(0);
header("Content-Type: text/html;charset=utf-8");


	require("../dbconfig.php");
	require("../functions.php");





	switch($_GET["action"]){
		case "add": 
			
			$name 	= $_POST["name"];
			$price 	= $_POST["price"];
			$total 	= $_POST["total"];
			$pic 	= $_POST["pic"];
			$note 	= $_POST["note"];
			$addtime = time();
			//2. verification
			if(empty($name)){
				die(errorTip("Must input product name", "addGoods.php?id={$id}"));
			}  
			
			//5. Assemble SQL statement and execute insertion
			$sql = "insert into goods values(null,'{$name}',{$price},{$total},'{$pic}','{$note}',{$addtime},null)";
			//echo $sql;
			mysql_query($sql);
			
			//6. Determine and output the result
			if(mysql_insert_id()>0){
				echo "<br><br>Add products successfully!";
			}else{
				echo "Fail to add product".mysql_error();
			}
			echo "<br><br/> <a href='goodsList.php'>Back to Product list<a>";
			
			
			break;
		
		case "del": 
			
			$sql = "delete from goods where id={$_GET['id']}";
			mysql_query($sql);
			
			if(mysql_affected_rows()>0){
				@unlink("../uploads/".$_GET['picname']);
				@unlink("../uploads/s_".$_GET['picname']);
			}
			
			header("Location:goodsList.php");
			break;
			
			
		case "update": 
			
			$name 	= $_POST["name"];
			$price 	= $_POST["price"];
			$total 	= $_POST["total"];
			$note 	= $_POST["note"];
			$id = $_POST['id'];
			$pic = $_POST['pic'];
			$updatetime 	= date('y-m-d H:i:s');
			
			if(empty($name)){
				die(errorTip("Must input product name", "editGoods.php?id={$id}"));
			}
			
			  
			
			$sql = "update goods set name='{$name}',price={$price},total={$total},note='{$note}',pic='{$pic}',updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			
			if(mysql_affected_rows()>0){
				echo "Modify Sucessfully";
			}else{
				echo "Fail to modify".mysql_error();
			}
			echo "<br/> <a href='goodsList.php'>Back to Product List<a>";
			
			break;

	}


mysql_close();



