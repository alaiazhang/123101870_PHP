<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Product Management</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
	</head>
	<body>
		
			<h3>Product List</h3>
			<!--<div class="admin_search_bar">
				<form action="<?php echo $_SERVER['PHP_SELF'];?>">
					<ul>
						<li><label>product name</label><input type="text" class="txt" name="keyword" value="<?php if(isset($_GET['keyword'])) echo $_GET['keyword'];?>"></li>
						<li><button>search</button></li>
					</ul>
				</form>
			</div>-->
			<table border="1" width="1200" class="frm_table">
				<tr>
                    <th style="width:60px;">Product Number</th>
                    <th style="width: 300px">Product Name</th>
                    <th style="width: 100px">Product Image</th>
                    <th style="width: 100px">Order Price</th>
                    <th style="width: 100px">Inventory</th>
                    <th style="width: 150px">Order Time</th>
                    <th>Action</th>
				</tr>
				<?php
				
				
				//Reading information from a database and outputting it to a browser form
				
					require("../dbconfig.php");
					
					// current page
					if(!isset($_GET["page"])){
						$page=1;
					}else{
						$page=$_GET["page"];
					}
					
			
					$temp=($page-1)*$list_num=100;
					
	
					if(!isset($_GET['keyword'])){
						$keyword = "";
					}else{
						$keyword = trim($_GET['keyword']);
					}
					
					
					
					$sql_count = "select count(*) as total from goods where 1 ORDER BY id ASC";
					if($keyword){
						$sql_count.= " and name like '%{$keyword}%'";
					}
					$result = mysql_query($sql_count);
					$res = mysql_fetch_array($result);
					$num=$res['total'];
					$p_count=ceil($num/$list_num);					
				
		
					$sql = "select * from goods where 1 ORDER BY id ASC ";
					if($keyword){
						$sql .=  " and name like '%{$keyword}%'";
					}
					$sql .= " limit {$temp},{$list_num}";
					$result = mysql_query($sql);
					
					
					
					while($row = mysql_fetch_assoc($result)){
						echo "<tr>";
						echo "<td>{$row['id']}</td>";
						echo "<td>{$row['name']}</td>";
						echo "<td><img src='../uploads/{$row['pic']}' width='100' height='100' /></td>";
						echo "<td>{$row['price']}</td>";
						echo "<td>{$row['total']}</td>";
						echo "<td>".date("Y-m-d H:i:s",$row['addtime'])."</td>";
						echo "<td> 
								<a href='goodsAction.php?action=del&id={$row['id']}' class='op_btn'>delete</a> 
								<a href='editGoods.php?id={$row['id']}' class='op_btn'>modify</a></td>";
						echo "</tr>";
					}
					
				
				

		
				
				?>
			</table> 
            <br>
	</body>
</html>