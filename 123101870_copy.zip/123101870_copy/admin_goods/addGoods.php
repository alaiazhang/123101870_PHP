<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Product Management</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
		<script type="text/javascript" src="../script/check.js"></script>
	</head>
	<body>
			<h3 class="page_title">Add product</h3>
			<form action="goodsAction.php?action=add" enctype="multipart/form-data" method="post" onSubmit="return validate_form(this)">
			<table border="0" width="1200" class="frm_table">
				<tr>
					<td align="right">Name:</td>
					<td><input type="text" name="name" autocomplete="off" class="frm_txt"/></td>
				</tr> 
				<tr>
					<td align="right">Price:</td>
					<td><input type="text" name="price" autocomplete="off" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">Inventory:</td>
					<td><input type="text" name="total" autocomplete="off" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">Image:</td>
					<td><input type="text" name="pic" autocomplete="off" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right" valign="top">Description:</td>
					<td><textarea rows="10" cols="70" name="note"></textarea>
				</tr>
				<tr>
					
					<td colspan="2" align="center">
						<input type="submit" value="Add"/>&nbsp;&nbsp;&nbsp;
						<input type="reset" value="Reset"/>
					</td>
				</tr>
			</table>
			</form>
			<script type="text/javascript">
		function validate_form(thisform){
			with (thisform){
				if (validate_required(name,"Must Input Product Name")==false){
					name.focus();
			      	return false;
			  }
				if (validate_required(price,"Must Input price")==false){
					price.focus();
			      	return false;
			  }

				if (validate_required(total,"Must input inventory")==false){
					total.focus();
			      	return false;
			  }
				if (validate_required(note,"Must input description")==false){
					note.focus();
			      	return false;
			  }
			}
		}
    </script>
	</body>
</html>