<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Product Information Management</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
		<script type="text/javascript" src="../script/check.js"></script>
	</head>
	<body>
			<?php  
			
					require("../dbconfig.php");
			
				
				
					$sql = "select * from goods where id={$_GET['id']}";
					$result = mysql_query($sql);
				
				
					if($result && mysql_num_rows($result)>0){
						$shop = mysql_fetch_assoc($result);
					}else{
						die("Can't find the product");
					}
			?>
			<h3 class="page_title">Modify Porduct Information</h3>
			<form action="goodsAction.php?action=update" enctype="multipart/form-data" method="post" onSubmit="return validate_form(this)">
				<input type="hidden" name="id" value="<?php echo $shop['id']; ?>"/>
				<input type="hidden" name="oldpic" value="<?php echo $shop['pic']; ?>"/>
			<table border="0" width="1200" class="frm_table">
				<tr>
					<td align="right">Name:</td>
					<td><input type="text" name="name" value="<?php echo $shop['name']; ?>" class="frm_txt"/></td>
				</tr>
				 
				<tr>
					<td align="right">Price:</td>
					<td><input type="text" name="price"  value="<?php echo $shop['price']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">Inventory:</td>
					<td><input type="text" name="total"  value="<?php echo $shop['total']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">Image:</td>
					<td><input type="text" name="pic"  value="<?php echo $shop['pic']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right" valign="top">Description:</td>
					<td><textarea rows="10" cols="70" name="note"><?php echo $shop['note']; ?></textarea>
				  
				</tr>
				<tr>
					
					<td colspan="2" align="center">
						<input type="submit" value="Modify"/>&nbsp;&nbsp;&nbsp;
						<input type="reset" value="Reset"/>
					</td>
				</tr>
				<tr>
					<td align="right" valign="top">&nbsp;</td>
					<td><img src="../uploads/<?php echo $shop['pic']; ?>" style="max-width: 200px;"/></td>
				</tr>
			</table>
			</form>
		<script type="text/javascript">
		function validate_form(thisform){
			with (thisform){
				if (validate_required(name,"Must input porudct name")==false){
					name.focus();
			      	return false;
			  }
				if (validate_required(price,"Must input price")==false){
					price.focus();
			      	return false;
			  }

				if (validate_required(total,"Must input inventory")==false){
					total.focus();
			      	return false;
			  }
				if (validate_required(note,"Must input description")==false){
					note.focus();
			      	return false;
			  }
			}
		}
    </script>
	</body>
</html>