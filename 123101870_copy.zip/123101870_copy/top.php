<?php 
	session_start();
	error_reporting(0);
	header("content-type:text/html;charset=utf-8"); 
?>
<div class="shop_header">
    	<h1 class="shop_title">Sense Explore Platform</h1>
    	
    	<div class="login_register_bar">
    		<?php 
    			if(isset($_SESSION) && isset($_SESSION['userId']) && $_SESSION['userId']){
    		?>
    		<?php 
    				if($_SESSION['adminId']){
    		?>
    		<a href="admin.php">Back-End</a>
    		|
    		<a href="loginAction.php?act=logout"style="margin-right: -10px">Log Out</a>
    		<?php 
    				}else{
    		?>
    		<a href="myOrderList.php">Order</a>
    		|
    		<a href="loginAction.php?act=logout">Exit</a>
    		<?php 
    				}
    		?>
    		<?php ?>
    			
    		<?php 
    			}else{
    		?>
    			<a href="login.php" style="margin-left: -20px">Log In</a>
    			|
    			<a href="register.php">Register</a>
    		<?php 
    			}
    		?>
    		
    		
    	</div>
    </div>
    <div class="shop_nav">
    	<ul>
    		<li><a href="index.php">Home Page</a></li>
    		<li><a href="myOrderList.php">Order</a></li>
    		<?php 
    			if(isset($_SESSION) && isset($_SESSION['userId']) && $_SESSION['userId']){
    		?>
    		<?php 
    			}
    		?>
    	</ul>
    </div>