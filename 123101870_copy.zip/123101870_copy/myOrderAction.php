<?php
session_start();
header("Content-Type: text/html;charset=utf-8");


	require("dbconfig.php");
	require("functions.php");



	switch($_GET["action"]){
		case "add": //add 
			// Getting added information
			$userId 		= $_SESSION['userId'];
			$goodsId 		= trim($_POST["goods_id"]);// product id
			$orderSn		= date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);// order number
			$consignee		= trim($_POST['consignee']);// recepient
			$phone			= trim($_POST['phone']);// tel number
			$address		= trim($_POST['address']);// address
			$orderMoney 	= 0;// order price
			// Check order price
			$sql = "select * from goods where id={$goodsId}";
			$result = mysql_query($sql);
			if($result && mysql_num_rows($result)>0){
				$goods = mysql_fetch_assoc($result);
				$orderMoney = $goods['price'];
			}else{
				alertMes('Product do not exist', 'index.php');
			}
			if($orderMoney <= 0){
				alertMes('Order price should >0', 'index.php');
			}
			
			$createtime 	= date('y-m-d H:i:s');// order time
			
			//2. verification
			if(empty($phone)){
				alertMes('Please input tel number', 'addOrder.php?id='.$goodsId);
			}
			if(empty($consignee)){
				alertMes('Please Input Recepient Name', 'addOrder.php?id='.$goodsId);
			}
			if(empty($address)){
				alertMes('Please Input address', 'addOrder.php?id='.$goodsId);
			}
			
			
			
			$sql = "insert into tb_order(user_id,goods_id,order_sn,order_money,consignee,phone,address,createtime) values('{$userId}','{$goodsId}','{$orderSn}','{$orderMoney}','{$consignee}','{$phone}','{$address}','{$createtime}')";
			//echo $sql;
			mysql_query($sql);
			
			if(mysql_insert_id()>0){
				alertMes('Order Successfully', 'myOrderList.php');
			}else{
				echo "Fail to Order!".mysql_error();
			}
			
			
			break;
		
		case "del": 
			$userId 		= $_SESSION['userId'];
			
			$sql = "delete from tb_order where id={$_GET['id']} and user_id={$userId}";;
			mysql_query($sql);
			
			
			header("Location:myOrderList.php");
			break;
			
			
		case "update": 
			
			$id 			= trim($_POST['id']);
			$orderMoney 	= trim($_POST["order_money"]);
			$consignee 		= trim($_POST["consignee"]);
			$address 		= trim($_POST["address"]);
			$phone 			= trim($_POST["phone"]);
			$updatetime 	= date('y-m-d H:i:s');
			//2. Data Verfication
			if(empty($orderMoney)){
				alertMes("Must input order price", "editOrder.php?id={$id}");
			}
			
			if(empty($consignee)){
				alertMes("Must input receipent", "editOrder.php?id={$id}");
			}
			
			if(empty($address)){
				alertMes("Must input address", "editOrder.php?id={$id}");
			}
			
			if(empty($phone)){
				alertMes("Must input tel number", "editOrder.php?id={$id}");
			}
			
			
			//3. Execute modification
			$sql = "update tb_order set order_money='{$orderMoney}', consignee='{$consignee}', address='{$address}', phone='{$phone}', updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			//6. Determine whether modify successfully
			if(mysql_affected_rows()>0){
				alertMes("Modify Successfully", "myOrderList.php");
			}else{
				
				alertMes("Fail to modify", "myOrderList.php");
			}
			
			break;

	}

mysql_close();


