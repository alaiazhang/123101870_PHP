<?php
header("Content-Type: text/html;charset=utf-8");



	require("dbconfig.php");
	require("functions.php");


	switch($_GET["action"]){
		case "add": 
		
			$username 		= trim($_POST["username"]);
			$password 		= trim($_POST["password"]);
			$repassword 	= trim($_POST["repassword"]);
			$createtime 	= date('y-m-d H:i:s');
			$md5Pwd 		= md5($password);
			
			if(empty($username)){
				alertMes('Must input user name', 'register.php');
			}
			if(empty($password)){
				alertMes('Must input password', 'register.php');
			}
			if($password != $repassword){
				alertMes('Must input', 'register.php');
			}
			
			// Determine if a user name is duplicated
			$sql_count = "select count(*) as total from user where username = '{$username}'";
			$result = mysql_query($sql_count);
			if($result){
				$res = mysql_fetch_array($result);
				$num=$res['total'];
				if($num > 0){
					alertMes('User name has existed', 'register.php');
				}
			}
			
			
			
			$sql = "insert into user(username, password,createtime)  values('{$username}','{$md5Pwd}','{$createtime}')";
			echo $sql;
			mysql_query($sql);
			
		
			if(mysql_insert_id()>0){
				alertMes('Register Successfully', 'login.php');
			}else{
				alertMes('Fail to register!', 'register.php');
			}
			
			
			break;
		
		

	}


mysql_close();


