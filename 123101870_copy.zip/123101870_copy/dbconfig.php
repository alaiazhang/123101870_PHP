<?php

error_reporting(0);
define("HOST","localhost:3307"); 
define("USER","root");		
define("PASS","");		
define("DBNAME","123101870_final");	
define("COPYRIGHT", ".");

if(!function_exists('mysql_pconnect')){
	function mysql_pconnect($dbhost, $dbuser, $dbpass){
		global $dbport;
		global $dbname;
		global $linkid;
		$linkid = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
		return $linkid;
	}
	function mysql_select_db($dbname){
		global $linkid;
		return mysqli_select_db($linkid,$dbname);
	}
	function mysql_fetch_array($result, $type=''){
		if ($type) {
			return mysqli_fetch_array($result, $type);
		}else{
			return mysqli_fetch_array($result);
		}
	}
	function mysql_fetch_assoc($result){
		return mysqli_fetch_assoc($result);
	}
	function mysql_fetch_row($result){
		return mysqli_fetch_row($result);
	}
	function mysql_free_result($result){
		return mysqli_free_result($result);
	}
	function mysql_query($cxn){
		global $linkid;
		return mysqli_query($linkid,$cxn);
	}
	function mysql_insert_id(){
		global $linkid;
		return mysqli_insert_id($linkid);
	}
	function mysql_affected_rows(){
		global $linkid;
		return mysqli_affected_rows($linkid);
	}
	function mysql_escape_string($data){
		global $linkid;
		return mysqli_real_escape_string($linkid, $data);
	}
	function mysql_real_escape_string($data){
		global $linkid;
		return mysqli_real_escape_string($linkid, $data);
	}
	function mysql_close(){
		global $linkid;
		return mysqli_close($linkid);
	}
	function mysql_get_server_info(){
		global $linkid;
		return mysqli_get_server_info($linkid);
	}
	function mysql_num_rows($result){
		return mysqli_num_rows($result);
	}
} 

if(version_compare(PHP_VERSION,'7.0.0', '<')){
	mysql_connect(HOST,USER,PASS) or die("db connect error".mysql_error());
}else{
	mysql_pconnect(HOST,USER,PASS) or die("db connect error".mysql_error());
}

mysql_select_db(DBNAME);
mysql_query("SET NAMES utf8");
