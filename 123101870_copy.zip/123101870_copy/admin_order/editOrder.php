<?php 
	
	require("../dbconfig.php");

	
	$sql = "SELECT a.*,b.username,c.`name` as `goods_name`,c.pic FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id and a.id={$_GET['id']}";
	$result = mysql_query($sql);
	
	
	if($result && mysql_num_rows($result)>0){
		$item = mysql_fetch_assoc($result);
	}else{
		die("Can't find the modified information");
	}
?>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Order List</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
		<script type="text/javascript" src="../script/check.js"></script>
	</head>
	<body>
			<h3 class="page_title">Edit Order</h3>
			<form action="orderAction.php?action=update" enctype="multipart/form-data" method="post" onSubmit="return validate_form(this)">
			<input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
			<table border="0" width="1200" class="frm_table">
				<tr>
					<td align="right">Order Number:</td>
					<td><input name="username" type="text" disabled class="frm_txt" value="<?php echo $item['order_sn'];?>" readonly/></td>
				</tr>
				<tr>
					<td align="right">Order Price:</td>
					<td><input type="text" name="order_money" class="frm_txt" value="<?php echo $item['order_money'];?>" /></td>
				</tr>
				
				<tr>
					<td align="right">Recipient:</td>
					<td><input type="text" name="consignee" class="frm_txt" value="<?php echo $item['consignee'];?>" /></td>
				</tr>
				
				<tr>
					<td align="right">Tel:</td>
					<td><input type="text" name="phone" class="frm_txt" value="<?php echo $item['phone'];?>" /></td>
				</tr>
				
				<tr>
					<td align="right">Address:</td>
					<td><input type="text" name="address" class="frm_txt" value="<?php echo $item['address'];?>" /></td>
				</tr>
				
				<tr>
					
					<td colspan="2" align="center">
						<input type="submit" value="Modify"/>&nbsp;&nbsp;&nbsp;
					</td>
				</tr>
			</table>
			</form>
		<script type="text/javascript">
		function validate_form(thisform){
			with (thisform){
				if (validate_required(order_money,"Please Input Order Price")==false){
					order_money.focus();
			      	return false;
			  }
				if (validate_required(consignee,"Please Input name of Recipient")==false){
					consignee.focus();
			      	return false;
			  }
				if (validate_required(phone,"Please input tel number")==false){
					phone.focus();
			      	return false;
			  }

				if (validate_required(address,"Please Input Address")==false){
					address.focus();
			      	return false;
			  }
			}
		}
    </script>
	</body>
</html>