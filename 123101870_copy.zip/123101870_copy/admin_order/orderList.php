<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Order List</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
	</head>
	<body>
		
			<h3>Order List</h3>
			<div class="admin_search_bar">
				<form action="<?php echo $_SERVER['PHP_SELF'];?>">
					<ul>
						<li><label>Product Name</label><input type="text" class="txt" name="keyword" value="<?php if(isset($_GET['keyword'])) echo $_GET['keyword'];?>"></li>
						<li><button>Search</button></li>
					</ul>
				</form>
			</div>
			<table border="1" width="1300" class="frm_table">
				<tr>
					<th style="width: 100px">Order Number</th>
					<th style="width: 100px">Who Order</th>
					<th style="width: 200px">Product Name</th>
					<th style="width: 100px">Product Image</th>
					<th style="width: 100px">Order Price</th>
					<th style="width: 200px">Recepient</th>
					<th style="width: 150px">Order Time</th>
					<th>Action</th>
				</tr>
				<?php
				
				
			 
					require("../dbconfig.php");
					
					
					if(!isset($_GET["page"])){
						$page=1;
					}else{
						$page=$_GET["page"];
					}
					
					
					$temp=($page-1)*$list_num=100;
					
					
					if(!isset($_GET['keyword'])){
						$keyword = "";
					}else{
						$keyword = trim($_GET['keyword']);
					}
					
					
				
					
					$sql_count = "SELECT count(*) as total FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
					if($keyword){
						$sql_count.= " and c.`name` like '%{$keyword}%'";
					}
					$result = mysql_query($sql_count);
					$res = mysql_fetch_array($result);
					$num=$res['total'];
					$p_count=ceil($num/$list_num);					
				
			
					$sql = "SELECT a.*,b.username,c.`name` as `goods_name`,c.pic FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
					if($keyword){
						$sql .=  " and c.`name` like '%{$keyword}%'";
					}
					$sql .= " limit {$temp},{$list_num}";
					$result = mysql_query($sql);
					
					
					
			
					while($row = mysql_fetch_assoc($result)){
						echo "<tr>";
						echo "<td>{$row['order_sn']}</td>";
						echo "<td>{$row['username']}</td>";
						echo "<td>{$row['goods_name']}</td>";
						echo "<td><img src='../uploads/{$row['pic']}' width='100' height='100'/></td>";
						echo "<td>{$row['order_money']}</td>";
						echo "<td>{$row['consignee']}<br>{$row['phone']}<br>{$row['address']}</td>";
						echo "<td>".$row['createtime']."</td>";
						echo "<td> 
								<a href='orderAction.php?action=del&id={$row['id']}' class='op_btn'>delete</a> 
								<a href='editOrder.php?id={$row['id']}' class='op_btn'>modify</a></td>";
						echo "</tr>";
					}
					
				
				
				?>
			</table>
			
	</body>
</html>