<?php
session_start();
header("Content-Type: text/html;charset=utf-8");

	require("../dbconfig.php");
	require("../functions.php");




//Get the value of the action parameter and do the corresponding action
	switch($_GET["action"]){
		
		case "del": 
			$sql = "delete from tb_order where id={$_GET['id']}";
			mysql_query($sql);
			
			header("Location:orderList.php");
			break;
			
			
		case "update": //modify
			// Get the information you want to modify
			$id 			= trim($_POST['id']);
			$orderMoney 	= trim($_POST["order_money"]);
			$consignee 		= trim($_POST["consignee"]);
			$address 		= trim($_POST["address"]);
			$phone 			= trim($_POST["phone"]);
			$updatetime 	= date('y-m-d H:i:s');
			//2. Validate data
			if(empty($orderMoney)){
				die(errorTip("Must Input Order Price", "editOrder.php?id={$id}"));
			}
			
			if(empty($consignee)){
				die(errorTip("Must Input Name of Receipant", "editOrder.php?id={$id}"));
			}
			
			if(empty($address)){
				die(errorTip("Must Input Address", "editOrder.php?id={$id}"));
			}
			
			if(empty($phone)){
				die(errorTip("Must Input tel number", "editOrder.php?id={$id}"));
			}
			
			
			// Execute  modification
			$sql = "update tb_order set order_money='{$orderMoney}', consignee='{$consignee}', address='{$address}', phone='{$phone}', updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			// Determine whether the modification is successful or not
			if(mysql_affected_rows()>0){
				echo "Modify Successfully";
			}else{
				echo "Fail to modify".mysqli_error();
			}
			echo "<br/> <a href='orderList.php'>Back<a>";
			
			break;

	}

mysql_close();


