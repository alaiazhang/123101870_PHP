<?php 
	require("../dbconfig.php");
	
	

	$sql = "select * from user where id={$_GET['id']}";
	$result = mysql_query($sql);
	
	if($result && mysql_num_rows($result)>0){
		$item = mysql_fetch_assoc($result);
	}else{
		die("Can't find information you want to modify");
	}
?>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>User Management</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
		<script type="text/javascript" src="../script/check.js"></script>
	</head>
	<body>
			<h3 class="page_title">Modify User Information</h3>
			<form action="userAction.php?action=update" enctype="multipart/form-data" method="post" onSubmit="return validate_form(this)">
			<input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
			<table border="0" width="900" class="frm_table">
				<tr>
					<td align="right">User Name:</td>
					<td><input type="text" name="username" class="frm_txt" value="<?php echo $item['username'];?>"/></td>
				</tr>
				
				
				<tr>
					
					<td colspan="2" align="center">
						<input type="submit" value="修改"/>&nbsp;&nbsp;&nbsp;
					</td>
				</tr>
			</table>
			</form>
	<script type="text/javascript">
		function validate_form(thisform){
			with (thisform){
				if (validate_required(username,"Please Enter user name:")==false){
					username.focus();
			      	return false;
			  }
			}
		}
    </script>
	</body>
</html>