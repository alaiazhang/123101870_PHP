<?php
header("Content-Type: text/html;charset=utf-8");



	require("../dbconfig.php");
	require("../functions.php");



	switch($_GET["action"]){
		case "add": //add
			
			$username 		= trim($_POST["username"]);
			$password 		= trim($_POST["password"]);
			$repassword 	= trim($_POST["repassword"]);
			$createtime 	= date('y-m-d H:i:s');
			$md5Pwd 		= md5($password);// 
			//2. validation
			if(empty($username)){
				die(errorTip("Must input user name", "addUser.php"));
			}
			if(empty($password)){
				die(errorTip("Must input password", "addUser.php"));
			}
			if($password != $repassword){
				die(errorTip("Passowrd do not match", "addUser.php"));
			}
			
			// Determine if a user name is duplicated
			$sql_count = "select count(*) as total from user where username = '{$username}'";
			$result = mysql_query($sql_count);
			if($result){
				$res = mysql_fetch_array($result);
				$num=$res['total'];
				if($num > 0){
					die(errorTip("User name has existed", "addUser.php"));
				}
			}
			
			
			
			$sql = "insert into user values(null,'{$username}','{$md5Pwd}','{$createtime}',null)";
			//echo $sql;
			mysql_query($sql);
			
		
			if(mysql_insert_id()>0){
				echo "Register Successfully!";
			}else{
				echo "Fail to Register!".mysqli_error();
			}
			echo "<br/> <a href='userList.php'>Back<a>";
			
			
			break;
		
		case "del": //delete
			
			$sql = "delete from user where id={$_GET['id']}";
			mysql_query($sql);
			
		
			header("Location:userList.php");
			break;
			
			
		case "update": //modify
			
			$username 		= trim($_POST["username"]);
			$id 			= trim($_POST['id']);
			$updatetime 	= date('y-m-d H:i:s');
			
			if(empty($username)){
				die(errorTip("Must input username", "editUser.php?id={$id}"));
			}
			
			
			
			$sql_count = "select count(*) as total from user where username = '{$username}' and id !={$id}";
			$result = mysql_query($sql_count);
			if($result){
				$res = mysql_fetch_array($result);
				$num=$res['total'];
				if($num > 0){
					die(errorTip("User name has existed", "editUser.php?id={$id}"));
				}
			}
			
			
			$sql = "update user set username='{$username}',updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
			
			
			if(mysql_affected_rows()>0){
				echo "Modify Successfully!";
			}else{
				echo "Fail to modify!".mysql_error();
			}
			echo "<br/> <a href='userList.php'>Back<a>";
			
			break;
		case "resetPwd":
			$id 			= trim($_POST['id']);
			$updatetime 	= date('y-m-d H:i:s');
			$password 		= trim($_POST["password"]);
			$repassword 	= trim($_POST["repassword"]);
			$createtime 	= date('y-m-d H:i:s');
			$md5Pwd 		= md5($password);// encryption for password
			// validation
			if(empty($password)){
				die(errorTip("Must input password", "resetUserPwd.php?id={$id}"));
			}
			if($password != $repassword){
				die(errorTip("Passwords do not match", "resetUserPwd.php?id={$id}"));
			}
			//2. Execute Modification
			$sql = "update user set password='{$md5Pwd}',updatetime='{$updatetime}' where id={$id}";
			//echo $sql;
			mysql_query($sql);
				
			//3. Determine whether the modification is successful or not
			if(mysql_affected_rows()>0){
				echo "Modify Scuccessfully";
			}else{
				echo "Fail to modify!".mysqli_error();
			}
			echo "<br/> <a href='userList.php'>返回<a>";
			break;

	}

// close database
mysql_close();


