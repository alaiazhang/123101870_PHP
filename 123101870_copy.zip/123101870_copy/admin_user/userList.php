<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>User Management</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
	</head>
	<body>
		
			<h3>User List</h3>
			<table border="1" width="1000" class="frm_table">
				<tr>
					<th>User Number</th>
					<th>User Name</th>
					<th>Register Time</th>
					<th>Action</th>
				</tr>
				<?php
				
				
					require("../dbconfig.php");
					
				
					if(!isset($_GET["page"])){
						$page=1;
					}else{
						$page=$_GET["page"];
					}
					
				
					$temp=($page-1)*$list_num=100;
					
			
					if(!isset($_GET['keyword'])){
						$keyword = "";
					}else{
						$keyword = trim($_GET['keyword']);
					}
					
					
					
					$sql_count = "select count(*) as total from user where 1 ORDER BY id ASC";
					if($keyword){
						$sql_count.= " and username like '%{$keyword}%'";
					}
					$result = mysql_query($sql_count);
					$res = mysql_fetch_array($result);
					$num=$res['total'];
					$p_count=ceil($num/$list_num);					
				
					$sql = "select * from user where 1 ORDER BY id ASC";
					if($keyword){
						$sql .=  " and username like '%{$keyword}%'";
					}
					$sql .= " limit {$temp},{$list_num}";
					$result = mysql_query($sql);
					
					
					
					
					while($row = mysql_fetch_assoc($result)){
						echo "<tr>";
						echo "<td>{$row['id']}</td>";
						echo "<td>{$row['username']}</td>";
						if($row['username'] != "admin"){
							echo "<td class='txt_center'>
							<a href='userAction.php?action=del&id={$row['id']}' class='op_btn'>delete</a>
							<a href='editUser.php?id={$row['id']}' class='op_btn'>modify</a>
							</td>";
						}else{
							echo "<td class='txt_center'>
							<a class='op_btn' onclick='cantDel();'>delete</a>
							<a href='editUser.php?id={$row['id']}' class='op_btn'>modify</a>
							</td>";
						}
						
						echo "</tr>";
					}
					
				
			
		
				
				?>
			</table>
			 
			<script>
				function cantDel(){
					alert("You can't delete administrator account");
				}
			</script>
	</body>
</html>