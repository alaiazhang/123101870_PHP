<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>Home Page</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
</head>

<body class="shop_body">
    <?php 
    	
		include 'top.php';
	?>
    <div class="shop_contain">
    	<ul class="overflow_hidden">
    	<?php 
	    	
	    	require_once "dbconfig.php" ;
	    		
	    	// Current Page
	    	if(!isset($_GET["page"])){
	    		$page=1;
	    	}else{
	    		$page=$_GET["page"];
	    	}
	    		
	    	// Number of products on the first page Pagination after exceeding the number of products
	    	$temp=($page-1)*$front_list_num=12;
	    		
	    	// Search keyword
	    	if(!isset($_GET['searchword'])){
	    		$searchword = "";
	    	}else{
	    		$searchword = trim($_GET['searchword']);
	    	}
	    		
	    		
	    	// Manage Database
	    		
	    	$sql_count = "select count(*) as total from goods where 1";
	    	if($searchword){
	    		$sql_count.= " and name like '%{$searchword}%'";
	    	}
	    	$result = mysql_query($sql_count);
	    	if($result){
	    		$res = mysql_fetch_array($result);
	    		$num=$res['total'];
	    	}else{
	    		$num = 0;
	    	}
	    	
	    	$p_count=ceil($num/$front_list_num);					
	    	
	    
	    	$sql = "select * from goods where 1";
	    	if($searchword){
	    		$sql .=  " and name like '%{$searchword}%'";
	    	}
	    	$sql .= " limit {$temp},{$front_list_num}";
	    	$result = mysql_query($sql);
	    	
	    	while($result && $row = mysql_fetch_assoc($result)){
    	?>
    		<li>
    			<div class="goods_item">
    				<a href="goodsDetail.php?id=<?php echo $row['id'];?>"><img src="uploads/<?php echo $row['pic'];?>" width="210" height="210" class="goods_img"></a>
    				<div class="goods_price">€<?php echo $row['price'];?></div>
    				<div class="goods_name"><?php echo $row['name'];?></div>
    			</div>
    		</li>
    	<?php 
	    	}
    	?>
    	
    	</ul>
    	<div class="page_contain">
    		<?php 
		
			if($num > 0){
				$prev_page=$page-1;					
				$next_page=$page+1;						
				echo "<p align=\"center\"> ";
				if ($prev_page<1)							
				{
					echo "  ";
				}
				else										
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$prev_page&searchword={$searchword}'>Previous Page</a> ";
				}
				if ($next_page>$p_count)						
				{
					echo "  ";
				}
				else										
				{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$next_page&searchword={$searchword}' class='underline'>Next Page</a> ";
				}
				 
			}else{
				echo "<P align='center'>No Record</p>";
			}
			?>
    	</div>

		<!-- Goole Map -->

		<div id="map" style="height: 400px; width: 100%;"></div>
        <script>
            function initMap() {
                var map = new google.maps.Map(document.getElementById('map'), {
                    center: {lat: -34.397, lng: 150.644}, 
                    zoom: 8 
                });
            }
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBbj1wxpO1JnoEZfqsot1Dy3KTDcYAA-Ng&callback=initMap" async defer></script>
        
		<!--  -->

        <?php 
    
		include 'foot.php';
	?>
    	</div>
    </div>
</body>

</html>