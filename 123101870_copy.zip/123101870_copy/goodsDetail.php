<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <title>Product Information</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
</head>

<body class="shop_body">
    <?php 
		include 'top.php';
	?>
    <div class="goods_detail_contain">
    	<?php  
				
					require_once "dbconfig.php";
				
					$sql = "select * from goods where id={$_GET['id']}";
					$result = mysql_query($sql);
				
					if($result && mysql_num_rows($result)>0){
						$shop = mysql_fetch_assoc($result);
					}else{
						die("Cant find product you want to modify");
					}
			
			
			
			?>
			<h3 class="page_title">Product Information</h3>
			<form  enctype="multipart/form-data" method="post">
				<input type="hidden" name="id" value="<?php echo $shop['id']; ?>"/>
				<input type="hidden" name="oldpic" value="<?php echo $shop['pic']; ?>"/>
			<table border="0" style="width:100%;" class="frm_table">
				<tr>
					<td align="right" width="60">Name:</td>
					<td><span  class="frm_txt"><?php echo $shop['name'];?></span></td>
				</tr> 
				<tr>
					<td align="right">Price</td>
					<td><span  class="frm_txt" id="unitPrice"><?php echo $shop['price'];?></span></td>
				</tr>
				<tr>
					<td align="right">Number</td>
					<td><span  class="frm_txt "><input type="number" id="quantity" ></span></td>
				</tr>
				<tr>
					<td align="right">Amount</td>
					<td><span  class="frm_txt amount" id="totalPrice"></span></td>
				</tr>
				<tr>
					<td align="right">Inventory</td>
					<td><span  class="frm_txt"><?php echo $shop['total'];?></span></td>
				</tr>
				
				
				<tr>
					<td align="right" valign="top">Description:</td>
					<td><span  class="frm_txt"><?php echo $shop['note'];?></span></td>
				</tr>
				<tr>
					<td align="right" valign="top">&nbsp;</td>
					<td><img src="./uploads/<?php echo $shop['pic']; ?>" style="max-width: 200px;"/>
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<a href="addOrder.php?id=<?php echo $_GET['id'];?>" class="buy" style="color:#FFF">Purchase</a>
					</td>
				</tr>
			</table>
			</form>
    </div>
</body>

</html>
<script>


  

  
//   Calculate the price
 

 document.getElementById('quantity').addEventListener('blur', function() {

  const unitPrice = parseFloat(document.getElementById('unitPrice').innerText);

  const quantity = document.getElementById('quantity').value;
    
	const totalPrice = unitPrice * quantity;
	document.getElementById('totalPrice').textContent = totalPrice;


	localStorage.setItem("amount", totalPrice);
});

</script>