<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    <script type="text/javascript" src="script/check.js"></script>
</head>

<body class="shop_body">
	<?php 
		include 'top.php';
	?>
    <div class="formContain">
    	<form action="registerAction.php?action=add" method="post" onsubmit="return validate_form(this)">
    		<h2 class="frm_title">Register</h2>
    		<p><span>User Name:</span><input type="text" name="username" autocomplete="off" style="width: 210px" class="txt-inp"></p>
    		<p><span>Password:</span><input type="password" name="password" style="width: 210px" class="txt-inp"></p>
    		<p><span>Repeat Password:</span><input type="password" name="repassword" style="width: 210px" class="txt-inp"></p>
    		<p class="txt_center"><input type="submit" value="regeister" class="frm-btn"></p>
    	</form>
    </div>
    <script type="text/javascript">
    function validate_form(thisform){
    	with (thisform){
	      if (validate_required(username,"Please Input user name:")==false){
		      	username.focus();
		      	return false;
		  }
	      if (validate_required(password,"Please input password")==false){
	    		 password.focus();
	    		 return false;
	     }
	      if (validate_required(repassword,"Please repeat password")==false){
	    	  repassword.focus();
	    		 return false;
	     }
		     if(validate_equal(password, repassword, "Passoword don't match") == false){
		    	 repassword.focus();
	    		 return false;
			 }
	  }
    }
    </script>
</body>

</html>