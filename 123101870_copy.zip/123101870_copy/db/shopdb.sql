

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `goods`
-- ----------------------------

CREATE DATABASE IF NOT EXISTS 123101870_final;

USE 123101870_final;

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
    `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(500) NOT NULL,
    `price` DOUBLE(6 , 2 ) UNSIGNED NOT NULL,
    `total` INT(10) UNSIGNED NOT NULL,
    `pic` VARCHAR(32) NOT NULL,
    `note` TEXT,
    `addtime` INT(10) UNSIGNED NOT NULL,
    `updatetime` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`)
)  ENGINE=MYISAM AUTO_INCREMENT=9 DEFAULT CHARSET=UTF8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('1', '1989', '10.0', '200', 'talor.jpg', 'Talor','1683308391' ,null);
INSERT INTO `goods` VALUES ('2', '20', '5.0', '2000', '20.jpg', 'R&B', '1683308577',null);
INSERT INTO `goods` VALUES ('3', 'Starboy','15.0', '89','starboy.jpg' ,'EDM','1683308577', null);
INSERT INTO `goods` VALUES ('4', 'Oasis', '13.0','100','oasis.jpeg', 'Rock', '1683309254',null);

-- ----------------------------
-- Table structure for `tb_order`
-- ----------------------------
DROP TABLE IF EXISTS `tb_order`;
CREATE TABLE `tb_order` (
    `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT(10) DEFAULT NULL,
    `goods_id` INT(10) DEFAULT NULL,
    `order_sn` VARCHAR(50) DEFAULT NULL COMMENT 'order number',
    `order_money` FLOAT(10 , 2 ) DEFAULT NULL COMMENT 'order price',
    `consignee` VARCHAR(20) DEFAULT NULL COMMENT 'recepient',
    `phone` VARCHAR(50) DEFAULT NULL,
    `address` VARCHAR(200) DEFAULT NULL COMMENT 'address',
    `createtime` DATETIME DEFAULT NULL,
    `updatetime` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`)
)  ENGINE=MYISAM AUTO_INCREMENT=1 DEFAULT CHARSET=UTF8;

-- ----------------------------
-- Records of tb_order
-- ----------------------------
INSERT INTO `tb_order` VALUES (1, 2, 1, '2023051023003', 19.90, 'John', '137789456321', 'westen', '2024-04-23 00:47:54', NULL);

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
    `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(30) DEFAULT NULL,
    `password` VARCHAR(50) DEFAULT NULL,
    `createtime` DATETIME DEFAULT NULL,
    `updatetime` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`)
)  ENGINE=MYISAM AUTO_INCREMENT=1 DEFAULT CHARSET=UTF8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2024-05-01 10:54:47', null);
INSERT INTO `user` VALUES ('2', 'user1', 'e10adc3949ba59abbe56e057f20f883e', '2024-05-01 10:54:47', null);