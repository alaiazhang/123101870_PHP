<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Order List</title>
		<link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
	</head>
	<body class="shop_body">
			<?php 
				include 'top.php';
				include 'functions.php';
				checkUserLogined();// Determine whether use has logged in
			?>
			<h3>Order List</h3> 
			<table border="1" style="width:100%;" class="frm_table">
				<tr>
					<th>Order Number</th>
					<th>Product Name</th>
					<th>Product Image</th>
					<th>Order Price</th>
					<th>Order Address</th>
					<th>Order Time</th>

				</tr>
				<?php
				
				
				
					require("dbconfig.php");
					
					if(!isset($_GET["page"])){
						$page=1;
					}else{
						$page=$_GET["page"];
					}
					
					$temp=($page-1)*$front_list_num=100;
					
					if(!isset($_GET['keyword'])){
						$keyword = "";
					}else{
						$keyword = trim($_GET['keyword']);
					}
					
					
				
					
					
					$sql_count = "SELECT count(*) as total FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
				
					$sql_count .= " AND a.user_id=".$_SESSION['userId'];
					if($keyword){
						$sql_count.= " and c.`name` like '%{$keyword}%'";
					}
					$result = mysql_query($sql_count);
					if($result){
						$res = mysql_fetch_array($result);
						$num = $res['total'];
					}else{
						$num = 0;
					}
					
					$p_count=ceil($num/$front_list_num);					
				
			
					$sql = "SELECT a.*,b.username,c.`name` as `goods_name`,c.pic FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
				
					$sql .= " AND a.user_id=".$_SESSION['userId'];
					
					if($keyword){
						$sql .=  " and c.`name` like '%{$keyword}%'";
					}
					$sql .= " limit {$temp},{$front_list_num}";
					$result = mysql_query($sql);
					
					
					
					
			
					while($result && $row = mysql_fetch_assoc($result)){
						echo "<tr>";
						echo "<td width='40'>{$row['order_sn']}</td>";
						echo "<td width='100'>{$row['goods_name']}</td>";
						echo "<td width='60'><img src='./uploads/{$row['pic']}' width='100' height='100'/> </td>";
						echo "<td width='60'>{$row['order_money']}</td>";
						echo "<td width='60'>{$row['consignee']}<br>{$row['phone']}<br>{$row['address']}</td>";
						echo "<td width='100'>".$row['createtime']."</td>";
				
					}
					
				
				
			
		
				
				?>
			</table>
			<?php 
   
		include 'foot.php';
	?>
	</body>
</html>